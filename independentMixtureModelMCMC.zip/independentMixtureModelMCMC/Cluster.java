package independentMixtureModelMCMC;

import java.util.*;

public class Cluster {
	static int FEATURE_NUM;
	static int CLUSTER_NUM;
	static int DATA_SIZE;
	static int DOC_SIZE;
	static double ALPHA=1;
	
	// Parameters
	HashMap<String, Long> ndz = new HashMap<String, Long>();
	
	HashMap<String, Double> theta;
	
	Distribution[] distributions;
	
	public Cluster(ArrayList<String> TYPE_LIST) {
		distributions = new Distribution[FEATURE_NUM];
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f] = newADistribution(TYPE_LIST.get(f));
		}
	}
	
	public Distribution newADistribution(String type_parameter) {
		Distribution distribution = null;
		
		String[] ss = type_parameter.split(":");
		String type = ss[0];
		String parameter = "";
		if (ss.length>1) {
			parameter = ss[1];
		}
		
//		if (type.equalsIgnoreCase("Gaussian")) {
//			distribution = new DistributionGaussian();
//		} else if (type.equalsIgnoreCase("GaussianMultivariate")) {
//			distribution = new DistributionGaussianMultivariate(parameter);
//		} else if (type.equalsIgnoreCase("Poisson")) {
//			distribution = new DistributionPoisson();
//		} else if (type.equalsIgnoreCase("Categorical")) {
		if (type.equalsIgnoreCase("Categorical")) {
			distribution = new DistributionCategorical(parameter);
		}
		
		return distribution;
	}
	
	public synchronized void add(String docName, String wordNames) {
		if (!ndz.containsKey(docName)) {
			ndz.put(docName, (long)0);
		}
		long value = ndz.get(docName);
		ndz.put(docName, value+1);
		
		String[] wordNameList = wordNames.split("\t");
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].add(wordNameList[f]);
		}
	}
	
	public synchronized void remove(String docName, String wordNames) {
		long value = ndz.get(docName);
		ndz.put(docName, value-1);
		
		String[] wordNameList = wordNames.split("\t");
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].remove(wordNameList[f]);
		}
	}
	
	public double getDensity(String docName, String wordNames, boolean bSame) {
		if (!ndz.containsKey(docName)) {
			ndz.put(docName, 0L);
		}
		
		double density = ALPHA + ndz.get(docName);
		if (bSame) {
			density = density - 1;
		}
		
		String[] wordNameList = wordNames.split("\t");
		for (int f=0; f<FEATURE_NUM; f++) {
			if (!wordNameList[f].equalsIgnoreCase("NG")&&!wordNameList[f].equalsIgnoreCase("")) {
				double value = distributions[f].getDensity(wordNameList[f], bSame);
				density *= value;
				if (Double.isNaN(value)) {
					System.out.println("dddNaN1!");
				}
			}
		}
		return density;
	}
	
	public double getLogDensity(String docName, String wordNames, boolean bSame) {
		if (!ndz.containsKey(docName)) {
			ndz.put(docName, 0L);
		}
		
		double density = ALPHA + ndz.get(docName);
		if (bSame) {
			density = density - 1;
		}
		double logdensity = Math.log(density);
		
		String[] wordNameList = wordNames.split("\t");
		for (int f=0; f<FEATURE_NUM; f++) {
			if (!wordNameList[f].equalsIgnoreCase("NG")&&!wordNameList[f].equalsIgnoreCase("")) {
				double value = distributions[f].getLogDensity(wordNameList[f], bSame);
				logdensity += value;
				if (Double.isNaN(value)) {
					System.out.println("dddNaN1!");
				}
			}
		}
		return logdensity;
	}
	
	public void inferParameter(HashMap<String, Double> sums) {
		theta = new HashMap<String, Double>();
		
		for (Iterator<Map.Entry<String, Long>> it=ndz.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Long> entry = it.next();
			String key = entry.getKey();
			long value = entry.getValue();
			
			theta.put(key, (ALPHA+value)/sums.get(key));
		}
		
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].inferParameter();
		}
	}
	
	public double computePerplexity(String docName, String wordNames) {
		double perplexity = theta.get(docName);
		
		String[] wordNameList = wordNames.split("\t");
		for (int f=0; f<FEATURE_NUM; f++) {
			if (!wordNameList[f].equalsIgnoreCase("NG")&&!wordNameList[f].equalsIgnoreCase("")) {
				double value = distributions[f].computePerplexity(wordNameList[f]);
				perplexity *= value;
			}
		}
		
		return perplexity;
	}
}
