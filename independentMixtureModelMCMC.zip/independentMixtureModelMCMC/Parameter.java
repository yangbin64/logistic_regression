package independentMixtureModelMCMC;

import java.io.*;
import java.util.*;

import com.google.gson.Gson;
import com.google.gson.stream.*;

public class Parameter {

	class ParameterList {
		String filename_training = "";
		String filename_result = "";
		String filename_testing = "";
		String filename_model = "";
		String pathname_dump = "";
		
		int HAS_ID;		// 0: no id; 1: has id
		
		double ALPHA;
		int FEATURE_NUM; // number of features
		int CLUSTER_NUM; // number of clusters
		int DATA_SIZE; // data size
		int DOC_SIZE;
		int THREAD_NUM;
		
		int start;
		int end;
		
		ArrayList<String> TYPE_LIST = new ArrayList<String>();
	}
	
	ParameterList parameterlist = new ParameterList();
	
	public void newJson(String filenameJson) {
		parameterlist = new ParameterList();
		exportJson(filenameJson);
	}
	
	public void importJson(String filenameJson) {
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(filenameJson));
			JsonReader jsr = new JsonReader(isr);
			Gson gson = new Gson();
			parameterlist = gson.fromJson(jsr, ParameterList.class);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void exportJson(String filenameJson) {
		File file = new File(filenameJson);
		try (JsonWriter writer = new JsonWriter(new FileWriter(file))) {
			writer.setIndent(" ");
			Gson gson = new Gson();
			gson.toJson(parameterlist, ParameterList.class, writer);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		Parameter p = new Parameter();
		p.parameterlist.filename_training = "E:\\Eagles\\Clustering\\data\\input.txt";
		p.parameterlist.filename_result = "E:\\Eagles\\Clustering\\output\\output.txt";
		p.parameterlist.pathname_dump = "E:\\Eagles\\Clustering\\dump\\";
		p.parameterlist.FEATURE_NUM = 6;
		p.parameterlist.CLUSTER_NUM = 20;
		p.parameterlist.TYPE_LIST.add("GaussianMultivariate");
		p.parameterlist.TYPE_LIST.add("Categorical");
		p.parameterlist.TYPE_LIST.add("Gaussian");
		p.parameterlist.TYPE_LIST.add("Categorical");
		p.parameterlist.TYPE_LIST.add("Categorical");
		p.parameterlist.TYPE_LIST.add("GaussianMultivariate");
		p.exportJson("E:\\Eagles\\Clustering\\run_all\\parameter.json");
		//p.importJson("C:\\temp\\parameter.json");
	}

}
