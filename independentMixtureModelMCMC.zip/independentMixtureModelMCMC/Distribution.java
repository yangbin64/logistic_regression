package independentMixtureModelMCMC;

import java.util.HashMap;

abstract class Distribution{
	static int FEATURE_NUM;
	static int CLUSTER_NUM;
	static int DATA_SIZE;
	
	HashMap<String, Double> phi = new HashMap<String, Double>();
	
	public abstract void add(String wordName);
	
	public abstract void remove(String wordName);
	
	public abstract double getDensity(String x, boolean bSame);
	
	public double getLogDensity(String x, boolean bSame) {
		return Math.log(getDensity(x, bSame));
	}
	
	public abstract void inferParameter();
	
	public abstract double computePerplexity(String wordName);
}
