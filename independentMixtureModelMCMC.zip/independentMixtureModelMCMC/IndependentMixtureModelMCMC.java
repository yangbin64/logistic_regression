package independentMixtureModelMCMC;

import java.io.*;
import java.util.*;

import org.apache.commons.math3.distribution.*;

public class IndependentMixtureModelMCMC {

	Cluster[] clusters;
	
	Parameter parameter;
	
	public IndependentMixtureModelMCMC(
			String filenameParameter) {
		parameter = new Parameter();
		parameter.importJson(filenameParameter);
		
		Cluster.FEATURE_NUM = parameter.parameterlist.FEATURE_NUM;
		Cluster.CLUSTER_NUM = parameter.parameterlist.CLUSTER_NUM;
		Cluster.ALPHA = parameter.parameterlist.ALPHA;
		
		clusters = new Cluster[parameter.parameterlist.CLUSTER_NUM];
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c] = new Cluster(parameter.parameterlist.TYPE_LIST);
		}
	}
	
	public void countSize() {
		int recordcount = 0;
		
		HashSet<String> DocSet = new HashSet<String>();
		
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t");
				
				recordcount++;
				
				String docName = ss[0];
				
				DocSet.add(docName);
				
				recordcount++;
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		parameter.parameterlist.DATA_SIZE = recordcount;
		Cluster.DATA_SIZE = recordcount;
		Distribution.DATA_SIZE = recordcount;
		
		parameter.parameterlist.DOC_SIZE = DocSet.size();
		Cluster.DOC_SIZE = parameter.parameterlist.DOC_SIZE;
		
		System.out.println("Doc count: " + parameter.parameterlist.DOC_SIZE);
		System.out.println("Record count:" + recordcount);
	}
	
	public void split(int round) {
		System.out.println("Spliting data from iteration " + round);
		try {
			FileWriter[] fws = new FileWriter[parameter.parameterlist.THREAD_NUM];
			for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
				fws[t] = new FileWriter(parameter.parameterlist.pathname_dump + "work_" + round + "_" + t + ".dat");
			}
			
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			String s;//=buf.readLine();
			
			int t_new = 0;
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t", 2);
				
				String docName = ss[0];
				String wordNames = ss[1];
				
				int z;
				if (ss.length==2) {
					UniformIntegerDistribution uniform = new UniformIntegerDistribution(0, parameter.parameterlist.CLUSTER_NUM-1);
					z = uniform.sample();
				} else {
					z = Integer.valueOf(ss[2]);
				}
				fws[t_new].write("" + z + "\t" + docName + "\t" + wordNames + "\n");
				t_new = (t_new+1)%parameter.parameterlist.THREAD_NUM;
			}
			
			fr.close();
			
			for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
				fws[t].close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void combine(int round) {
		try {
			FileReader[] frs = new FileReader[parameter.parameterlist.THREAD_NUM];
			BufferedReader[] bufs = new BufferedReader[parameter.parameterlist.THREAD_NUM];
			String[] s = new String[parameter.parameterlist.THREAD_NUM];
			
			for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
				frs[t] = new FileReader(parameter.parameterlist.pathname_dump + "work_" + round + "_" + t + ".dat");
				bufs[t] = new BufferedReader(frs[t]);
			}
			
			String filenamew = parameter.parameterlist.pathname_dump + "result.dat";
			FileWriter fw = new FileWriter(filenamew);
			
			boolean bContinue = true;
			while (bContinue) {
				bContinue = false;
				for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
					if ((s[t]=bufs[t].readLine())!=null) {
						String[] ss=s[t].split("\t", 3);
						
						int z = Integer.valueOf(ss[0]);
						String docName = ss[1];
						String wordNames = ss[2];
						
						fw.write("" + z + "\t" + docName + "\t" + wordNames + "\n");
						
						bContinue = true;
					}
				}
			}
			
			fw.close();
			
			for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
				frs[t].close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void construct(int round) {
		try {
			int recordcount = 0;
			for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
				FileReader fr = new FileReader(parameter.parameterlist.pathname_dump + "work_" + round + "_" + t + ".dat");
				BufferedReader buf = new BufferedReader(fr);
				String s;
				
				while ((s=buf.readLine())!=null) {
					String[] ss=s.split("\t", 3);
					
					int z = Integer.valueOf(ss[0]);
					String docName = ss[1];
					String wordNames = ss[2];
					
					clusters[z].add(docName, wordNames);
					
					recordcount++;
				}
				
				fr.close();
			}
			
			System.out.println("Record count:" + recordcount);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public class Sampler implements Runnable {
		int round;
		String filename;
		String filename_new;
		
		public Sampler(int r, String file, String file_new) {
			round = r;
			filename = file;
			filename_new = file_new;
		}
		
		public void run() {
			System.out.println("[Round" + round + "] Thread for [" + filename + "] is started.");
			
			int changedNum = 0;
			int sampledNum = 0;
			try {
				FileReader fr = new FileReader(filename);
				BufferedReader buf = new BufferedReader(fr);
				String s;
				
				FileWriter fw = new FileWriter(filename_new);
				
				while ((s=buf.readLine())!=null) {
					String[] ss=s.split("\t", 3);
					
					int z = Integer.valueOf(ss[0]);
					String docName = ss[1];
					String wordNames = ss[2];
					
					int z_new = sample(z, docName, wordNames);
					if (z_new != z) {
						changedNum++;
					}
					sampledNum++;
					
					fw.write("" + z_new + "\t" + docName + "\t" + wordNames + "\n");
				}
				
				fw.close();
				
				fr.close();
			} catch (Exception e) {
				System.out.println(e);
			}
			
			try {
				File file = new File(filename);
			    if (file.exists()) {
			    	file.delete();
			    }
			} catch (Exception e) {
				System.out.println(e);
			}
			
			System.out.println("[Round" + round + "] Thread  for [" + filename + "] finished (" + changedNum + "/" + sampledNum + ").");
		}
		
		public int sample(int z, String docName, String wordNames) {
			int[] singletons = new int[parameter.parameterlist.CLUSTER_NUM];
			double[] probabilities = new double[parameter.parameterlist.CLUSTER_NUM];
			double[] logprobabilities = new double[parameter.parameterlist.CLUSTER_NUM];
			
			double maxlogprob = -1.0e300;
			for (int j=0; j<parameter.parameterlist.CLUSTER_NUM; j++) {
				singletons[j] = j;
				logprobabilities[j] = clusters[j].getLogDensity(docName, wordNames, j==z);
				if (logprobabilities[j]>maxlogprob)
					maxlogprob = logprobabilities[j];
			}
			for (int j=0; j<parameter.parameterlist.CLUSTER_NUM; j++) {
				probabilities[j] = Math.exp(logprobabilities[j] - maxlogprob);
			}
			
			EnumeratedIntegerDistribution discrete;
			int z_new;
			try {
				discrete = new EnumeratedIntegerDistribution(singletons, probabilities);
				z_new = discrete.sample();
				
				update(z, z_new, docName, wordNames);
				
				return z_new;
			} catch(Exception e) {
				double sumprob = 0;
				for (int j=0; j<parameter.parameterlist.CLUSTER_NUM; j++) {
					sumprob += probabilities[j];
				}
				System.out.println(sumprob);
				System.out.println(e);
			}
			
			return -1;
		}
		
		public void update(int z, int z_new, String docName, String wordNames) {
			clusters[z].remove(docName, wordNames);
			clusters[z_new].add(docName, wordNames);
		}
	}
	
	public void sampling(int round) {
		// run threads
		Thread[] threads = new Thread[parameter.parameterlist.THREAD_NUM];
		
		for (int t=0; t<parameter.parameterlist.THREAD_NUM; t++) {
			String filename = parameter.parameterlist.pathname_dump + "work_" + round + "_" + t + ".dat";
			String filename_new = parameter.parameterlist.pathname_dump + "work_" + (round+1) + "_" + t + ".dat";
			threads[t] = new Thread(new Sampler(round, filename, filename_new));
			threads[t].start();
		}
		
		try {
			for (int i=0; i<parameter.parameterlist.THREAD_NUM; i++) {
				threads[i].join();
			}
		} catch (InterruptedException e) {
			System.out.println(e);
		}
	}
	
	public void train(int r_begin, int r_end) {
		try {
			FileWriter fw = new FileWriter(parameter.parameterlist.pathname_dump + "loglikelihood.dmp");
			
			for (int r=r_begin; r<=r_end; r++) {
				System.out.println("Round " + r + "...");
				sampling(r);
				combine(r+1);
				inferParameter();
				double perp = computePerplexity();
				fw.write("" + perp + "\n");
			}
			saveModel();
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void assignLabels() {
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			String s=buf.readLine();
			
			FileWriter fw = new FileWriter(parameter.parameterlist.filename_result);
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t");
				
				String[] xx = new String[parameter.parameterlist.FEATURE_NUM];
				boolean bNG = true;
				for (int f=0; f<parameter.parameterlist.FEATURE_NUM; f++) {
					xx[f] = ss[f+parameter.parameterlist.HAS_ID];
					if (!xx[f].equalsIgnoreCase("NG")&&!xx[f].equalsIgnoreCase("")) {
						bNG = false;
					}
				}
				
				if (bNG) {
					fw.write("" + "NG" + "\t" + s + "\n");
				} else {
					int c_max = assignLabels(xx);
					fw.write("" + c_max + "\t" + s + "\n");
				}
			}
			
			fw.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public int assignLabels(String[] xx) {
		// compute w
		//double[] w = computeW(xx);
		
		int c_max = 0;
		//for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
		//	if (w[c] > w[c_max]) {
		//		c_max = c;
		//	}
		//}
		
		return c_max;
	}
	
	public void inferParameter() {
		HashMap<String, Double> sums = new HashMap<String, Double>();
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			for (Iterator<Map.Entry<String, Long>> it=clusters[c].ndz.entrySet().iterator(); it.hasNext(); ) {
				Map.Entry<String, Long> entry = it.next();
				String docName = entry.getKey();
				long count = entry.getValue();
				
				if (!sums.containsKey(docName)) {
					sums.put(docName, 0.0);
				}
				
				double value = sums.get(docName);
				sums.put(docName, value + count + Cluster.ALPHA);
			}
		}
		
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c].inferParameter(sums);
		}
	}
	
	public void saveModel() {
		try {
			// output theta >>>>>>>>>>
			FileWriter fw_theta = new FileWriter(parameter.parameterlist.filename_model + "_theta.txt");
			
			// output the header
			for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
				fw_theta.write("\t" + c);
			}
			fw_theta.write("\n");
			
			// output the contents
			for (Iterator<Map.Entry<String, Double>> it=clusters[0].theta.entrySet().iterator(); it.hasNext(); ) {
				Map.Entry<String, Double> entry = it.next();
				String docName = entry.getKey();
				
				fw_theta.write(docName);
				
				for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
					double p = clusters[c].theta.get(docName);
					fw_theta.write("\t" + p);
				}
				fw_theta.write("\n");
			}
			
			fw_theta.close();
			// output theta <<<<<<<<<<
			
			// output phi >>>>>>>>>>
			for (int f=0; f<parameter.parameterlist.FEATURE_NUM; f++) {
				FileWriter fw_phi = new FileWriter(parameter.parameterlist.filename_model + "_phi_" + f + ".txt");
				
				// output the header
				ArrayList<String> header = new ArrayList<String>();
				for (Iterator<Map.Entry<String, Double>> it=clusters[0].distributions[f].phi.entrySet().iterator(); it.hasNext(); ) {
					Map.Entry<String, Double> entry = it.next();
					String wordName = entry.getKey();
					header.add(wordName);
					//double value = entry.getValue();
					//fw_phi.write("\t" + wordName + ":" + value);
				}
				for (Iterator<String> it=header.iterator(); it.hasNext(); ) {
					String wordName = it.next();
					fw_phi.write("\t" + wordName);
				}
				fw_phi.write("\n");
				
				// output the contents
				for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
					fw_phi.write("" + c);
					
					for (Iterator<String> it=header.iterator(); it.hasNext(); ) {
						String wordName = it.next();
						double value = clusters[c].distributions[f].phi.get(wordName);
						fw_phi.write("\t" + value);
					}
					fw_phi.write("\n");
				}
				
				fw_phi.close();
			}
			// output phi <<<<<<<<<<
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void loadModel() {
		try {
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public double computePerplexity() {
		double sum_ll = 0;
		int count = 0;
		
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_testing);
			BufferedReader buf = new BufferedReader(fr);
			String s=buf.readLine();
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t", 2);
				String docName = ss[0];
				String wordNames = ss[1];
				double logLikelihood = computePerplexity(docName, wordNames);
				sum_ll += logLikelihood;
				count++;
				
				if (count%2000==0) {
					System.out.print("*");
				}
			}
			
			fr.close();
		} catch(Exception e) {
			System.out.println(e);
		}
		
		double ll = sum_ll/count;
		
		System.out.println("Perplexity: " + ll);
		
		return ll;
	}
	
	public double computePerplexity(String docName, String wordNames) {
		double sumJointDensity = 0;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			double jointDensity = clusters[c].computePerplexity(docName, wordNames);
			sumJointDensity += jointDensity;
		}
		
		double logSumJointDensity = Math.log(sumJointDensity);
		
		return logSumJointDensity;
	}
	
	public void run(String flg) {
		countSize();
		
		if (flg.equalsIgnoreCase("testing")) {
			//System.out.println("Loading model...");
			//loadClusters(parameter.parameterlist.filename_model);
			
		} else if (flg.equalsIgnoreCase("training")) {
			if (parameter.parameterlist.start==0)
				split(0);
			construct(parameter.parameterlist.start);
			
			System.out.println("Training from round " + parameter.parameterlist.start + "...");
			train(parameter.parameterlist.start, parameter.parameterlist.end);
			
			//System.out.println("Assigning labels...");
			//assignLabels();
			
		} else if (flg.equalsIgnoreCase("assigning")) {
			//System.out.println("Loading model...");
			//loadClusters(parameter.parameterlist.filename_model);
			
			//System.out.println("Assigning labels...");
			//assignLabels();
		}
		
		System.out.println("Computing log perplexity...");
		inferParameter();
		computePerplexity();
	}
	
	public static void main(String[] args) {
		String flg = args[0];
		String filenameParameter = args[1];
		
		IndependentMixtureModelMCMC imm = new IndependentMixtureModelMCMC(filenameParameter);
		
		imm.run(flg);
	}

}
