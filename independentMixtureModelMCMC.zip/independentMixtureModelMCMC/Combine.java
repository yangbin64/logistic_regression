package independentMixtureModelMCMC;

import java.io.*;

public class Combine {

	public void combine(int round, int thread_num, String pathname_dump) {
		try {
			FileReader[] frs = new FileReader[thread_num];
			BufferedReader[] bufs = new BufferedReader[thread_num];
			String[] s = new String[thread_num];
			
			for (int t=0; t<thread_num; t++) {
				frs[t] = new FileReader(pathname_dump + "work_" + round + "_" + t + ".dat");
				bufs[t] = new BufferedReader(frs[t]);
			}
			
			String filenamew = pathname_dump + "result.dat";
			FileWriter fw = new FileWriter(filenamew);
			
			boolean bContinue = true;
			while (bContinue) {
				bContinue = false;
				for (int t=0; t<thread_num; t++) {
					if ((s[t]=bufs[t].readLine())!=null) {
						String[] ss=s[t].split("\t", 3);
						
						int z = Integer.valueOf(ss[0]);
						String docName = ss[1];
						String wordNames = ss[2];
						
						fw.write("" + z + "\t" + docName + "\t" + wordNames + "\n");
						
						bContinue = true;
					}
				}
			}
			
			fw.close();
			
			for (int t=0; t<thread_num; t++) {
				frs[t].close();
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void main(String[] args) {
		Combine c = new Combine();
		int round = Integer.valueOf(args[0]);
		int thread_num = Integer.valueOf(args[1]);
		String pathname_dump = args[2];
		c.combine(round, thread_num, pathname_dump);
	}

}
