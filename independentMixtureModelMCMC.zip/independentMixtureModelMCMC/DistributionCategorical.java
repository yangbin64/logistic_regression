package independentMixtureModelMCMC;

import java.util.*;

public class DistributionCategorical extends Distribution {

	//double alpha = 50;
	double BETA;
	
	// Parameters
	long nz;
	HashMap<String, Long> nzw = new HashMap<String, Long>();
	
	int C;
	HashMap<String, Double> probabilities;
	
	// Work area
	HashMap<String, Double> n;
	//double N = 0;
	
	//EnumeratedDistribution<String> categorical;
	
	public DistributionCategorical(String parameter) {
		String[] parameters = parameter.split(";");
		
		String[] keys = parameters[0].split(",");
		C = keys.length;
		
		probabilities = new HashMap<String, Double>();
		for (int c=0; c<C; c++) {
			String key = keys[c];
			probabilities.put(key, 1.0/C);
		}
		
		BETA = Double.valueOf(parameters[1]);
	}
	
	
	public void add(String wordName) {
		if (!wordName.equalsIgnoreCase("NG")&!wordName.contentEquals("")) {
			nz++;
			if (!nzw.containsKey(wordName)) {
				nzw.put(wordName, (long)0);
			}
			long value = nzw.get(wordName);
			nzw.put(wordName, value+1);
		}
	}
	
	public void remove(String wordName) {
		if (!wordName.equalsIgnoreCase("NG")&!wordName.contentEquals("")) {
			nz--;
			long value = nzw.get(wordName);
			nzw.put(wordName, value-1);
		}
	}
	
	public double getDensity(String wordName, boolean bSame) {
		double density = 1.0;
		
		if (!nzw.containsKey(wordName)) {
			nzw.put(wordName, 0L);
		}
		
		if (!wordName.equalsIgnoreCase("NG")&!wordName.contentEquals("")) {
			if (bSame) {
				density = (BETA + nzw.get(wordName) - 1)/(BETA*C + nz - 1);
			} else {
				density = (BETA + nzw.get(wordName))/(BETA*C + nz);
			}
		}
		
		return density;
	}
	
	public void inferParameter() {
		double sum = 0;
		for (Iterator<Map.Entry<String, Long>> it=nzw.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Long> entry = it.next();
			double value = BETA + entry.getValue();
			sum += value;
		}
		
		for (Iterator<Map.Entry<String, Long>> it=nzw.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Long> entry = it.next();
			String wordName = entry.getKey();
			double value = BETA + entry.getValue();
			double probability = value / sum;
			phi.put(wordName, probability);
		}
	}
	
	public double computePerplexity(String wordName) {
		return phi.get(wordName);
	}
}
