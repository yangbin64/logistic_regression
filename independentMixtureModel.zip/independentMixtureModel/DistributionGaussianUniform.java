package independentMixtureModel;

import org.apache.commons.math3.distribution.*;

public class DistributionGaussianUniform extends Distribution {

	double sigma2 = 1;
	
	int DIM;
	
	// Parameters
	double[] mu;
	double[][] Sigma;
//	double[][] Sigma_inv;
//	double Sigma_logDet;
	
	// Work area
	double[] sum;
	double[][] sum2;
	
	MultivariateNormalDistribution gaussian;
	
	public DistributionGaussianUniform(String parameter) {
		String[] parameters = parameter.split(";");
		DIM = Integer.valueOf(parameters[0]);
		sigma2 = Double.valueOf(parameters[1]);
	}
	
	public void initWorkArea() {
		Nk_local = 0;
		sum = new double[DIM];
		sum2 = new double[DIM][DIM];
	}
	
	public void updateWorkArea(double w, String x) {
		Nk_local += w;
		
		String[] xx = x.split(";");
		
		double[] value = new double[DIM];
		for (int d=0; d<DIM; d++) {
			value[d] = Double.valueOf(xx[d]);
		}
		
		for (int d=0; d<DIM; d++) {
			sum[d] += w*value[d];
		}
		
		for (int d=0; d<DIM; d++) {
			for (int d2=d; d2<DIM; d2++) {
				sum2[d][d2] += w*value[d]*value[d2];
				if (d!=d2) {
					sum2[d2][d] = sum2[d][d2];
				}
			}
		}
	}
	
	public void initHyperParameter() {
		mu = new double[DIM];
		Sigma = new double[DIM][DIM];
		
		UniformRealDistribution uniform = new UniformRealDistribution();
		
		for (int d=0; d<DIM; d++) {
			//mu[d] = uniform.sample()*100+50;
			mu[d] = uniform.sample();
		}
		
		for (int d=0; d<DIM; d++) {
			for (int d2=0; d2<DIM; d2++) {
				if (d==d2) {
					Sigma[d][d2] = sigma2;
				} else {
					Sigma[d][d2] = 0.0;
				}
			}
		}
		
//		computeMatrix();
	}
	
	public void updateHyperParameter() {
		for (int d=0; d<DIM; d++) {
			mu[d] = sum[d]/Nk_local;
		}
		
//		computeMatrix();
	}
	
/*	public void computeMatrix() {
		// Compute inverse of matrix sd, using LU decomposition
		RealMatrix matrix = MatrixUtils.createRealMatrix(Sigma);
		RealMatrix inverse = new LUDecomposition(matrix).getSolver().getInverse();
		Sigma_inv = inverse.getData();
		
		// Compute determinate of matrix sd, using Cholesky decomposition
		Sigma_logDet = 0;
		CholeskyDecomposition CD = new CholeskyDecomposition(matrix);
		RealMatrix L = CD.getL();
		double[][] l = L.getData();
		for (int d=0; d<DIM; d++) {
			Sigma_logDet += Math.log(Math.abs(l[d][d]));
			if (l[d][d]<0) {
				System.out.println("Negative!");;
			}
		}
		RealMatrix LT = CD.getLT();
		double[][] lt = LT.getData();
		for (int d=0; d<DIM; d++) {
			Sigma_logDet += Math.log(Math.abs(lt[d][d]));
			if (l[d][d]<0) {
				System.out.println("Negative!");
			}
		}
	}*/
	
	public void updateDistribution() {
		try {
			gaussian = new MultivariateNormalDistribution(mu, Sigma);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public double getLogDensity(String x) {
		String[] xx = x.split(";");
		double[] value = new double[DIM];
		for (int d=0; d<DIM; d++) {
			value[d] = Double.valueOf(xx[d]);
		}
		
		double logDensity = -0.5 * DIM * Math.log(Math.PI*2);
		logDensity += -0.5 * DIM * Math.log(sigma2);
		
		for (int d=0; d<DIM; d++) {
			logDensity += -0.5 * (value[d]-mu[d]) * (value[d]-mu[d]) / sigma2;
		}
		
		return logDensity;
	}
	
	public String saveCluster() {
		// mu
		String clusterParameter = "";
		
		for (int d=0; d<DIM; d++) {
			if (d==0) {
				clusterParameter += "" + mu[d];
			} else {
				clusterParameter += "," + mu[d];
			}
		}

		for (int d=0; d<DIM; d++) {
			for (int d2=0; d2<DIM; d2++) {
				if (d==0 && d2==0) {
					clusterParameter += ";" + Sigma[d][d2];
				} else {
					clusterParameter += "," + Sigma[d][d2];
				}
			}
		}
		
		return clusterParameter;
	}
	
	public void loadCluster(String s) {
		String[] ss = s.split(";");
		
		// mu
		String[] sss1 = ss[0].split(",");
		for (int d=0; d<DIM; d++) {
			mu[d] = Double.valueOf(sss1[d]);
		}
		
		// Sigma
		String[] sss2 = ss[1].split(",");
		for (int d=0; d<DIM; d++) {
			for (int d2=0; d2<DIM; d2++) {
				Sigma[d][d2] = Double.valueOf(sss2[d*DIM+d2]);
			}
		}
		
//		computeMatrix();
		
		// distribution
		updateDistribution();
	}
}
