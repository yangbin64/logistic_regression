package independentMixtureModel;

import org.apache.commons.math3.distribution.*;

public class DistributionPoisson extends Distribution {

	// Parameters
	double mu = 0;
	
	// Work area
	double sum_mu = 0;
	
	PoissonDistribution poisson;
	
	public void initWorkArea() {
		Nk_local = 0;
		sum_mu = 0;
	}
	
	public void updateWorkArea(double w, String x) {
		Nk_local += w;
		sum_mu += w*Double.valueOf(x);
	}
	
	public void initHyperParameter() {
		UniformRealDistribution uniform = new UniformRealDistribution();
		
		mu = uniform.sample();
	}
	
	public void updateHyperParameter() {
		mu = sum_mu/Nk_local;
	}
	
	public void updateDistribution() {
		try {
			poisson = new PoissonDistribution(mu);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public double getLogDensity(String x) {
		int xi = (int)(Double.valueOf(x)+0.1);
		return poisson.logProbability(xi);
	}
	
	public String saveCluster() {
		// mu
		String clusterParameter = "" + mu;

		return clusterParameter;
	}
	
	public void loadCluster(String s) {
		// mu
		mu = Double.valueOf(s);
		
		// distribution
		updateDistribution();
	}
}
