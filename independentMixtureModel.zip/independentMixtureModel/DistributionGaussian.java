package independentMixtureModel;

import org.apache.commons.math3.distribution.*;

public class DistributionGaussian extends Distribution {

	static double alpha = 0.8;
			
	// Parameters
	double mu = 0;
	double sd = 0;
	
	// Work area
	double sum = 0;
	double sum2 = 0;
	
	NormalDistribution gaussian;
	
	public void initWorkArea() {
		Nk_local = 0;
		sum = 0;
		sum2 = 0;
	}
	
	public void updateWorkArea(double w, String x) {
		Nk_local += w;
		
		double value = Double.valueOf(x);
		sum += w*value;
		sum2 += w*value*value;
	}
	
	public void initHyperParameter() {
		UniformRealDistribution uniform = new UniformRealDistribution();
		
		mu = uniform.sample()*50+100;
		sd = 10.0;
	}
	
	public void updateHyperParameter() {
		mu = sum/Nk_local;
		sd = Math.sqrt(sum2/Nk_local - mu*mu + alpha);
	}
	
	public void updateDistribution() {
		try {
			gaussian = new NormalDistribution(mu, sd);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public double getLogDensity(String x) {
		double value = Double.valueOf(x);
		return gaussian.logDensity(value);
	}
	
	public String saveCluster() {
		// mu
		String clusterParameter = "" + mu + ";" + sd;

		return clusterParameter;
	}
	
	public void loadCluster(String s) {
		String[] ss = s.split(";");
		
		// mu
		mu = Double.valueOf(ss[0]);
		sd = Double.valueOf(ss[1]);
		
		// distribution
		updateDistribution();
	}
}
