package independentMixtureModel;

import java.util.*;

public class Cluster {
	static int FEATURE_NUM;
	static int CLUSTER_NUM;
	static int DATA_SIZE;
	
	// Parameters
	double pi = 0;
	
	// Work area
	double Nk = 0;
	
	Distribution[] distributions;
	
	public Cluster(ArrayList<String> TYPE_LIST) {
		distributions = new Distribution[FEATURE_NUM];
		for (int f=0; f<FEATURE_NUM; f++) {
			pi = 1.0/CLUSTER_NUM;
			distributions[f] = newADistribution(TYPE_LIST.get(f));
			distributions[f].initHyperParameter();
			distributions[f].updateDistribution();
		}
	}
	
	public Distribution newADistribution(String type_parameter) {
		Distribution distribution = null;
		
		String[] ss = type_parameter.split(":");
		String type = ss[0];
		String parameter = "";
		if (ss.length>1) {
			parameter = ss[1];
		}
		
		if (type.equalsIgnoreCase("Gaussian")) {
			distribution = new DistributionGaussian();
		} else if (type.equalsIgnoreCase("GaussianUniform")) {
			distribution = new DistributionGaussianUniform(parameter);
		} else if (type.equalsIgnoreCase("GaussianMultivariate")) {
			distribution = new DistributionGaussianMultivariate(parameter);
		} else if (type.equalsIgnoreCase("Poisson")) {
			distribution = new DistributionPoisson();
		} else if (type.equalsIgnoreCase("Categorical")) {
			distribution = new DistributionCategorical(parameter);
		}
		
		return distribution;
	}
	
	public void initWorkArea() {
		Nk = 0;
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].initWorkArea();
		}
	}
	
	public void updateWorkArea(double w, String[] xx) {
		Nk += w;
		
		for (int f=0; f<FEATURE_NUM; f++) {
			if (!xx[f].equalsIgnoreCase("NG")&&!xx[f].equalsIgnoreCase("")) {
				distributions[f].updateWorkArea(w, xx[f]);
			}
		}
	}
	
	public void updatePi() {
		pi = Nk/DATA_SIZE;
	}
	
	public void updateHyperParameter() {
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].updateHyperParameter();
		}
	}
	
	public void updateDistribution() {
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].updateDistribution();
		}
	}
	
	public double getLogDensity(String[] xx) {
		double logDensity = 0.0;
		for (int f=0; f<FEATURE_NUM; f++) {
			if (!xx[f].equalsIgnoreCase("NG")&&!xx[f].equalsIgnoreCase("")) {
				double value = distributions[f].getLogDensity(xx[f]);
				logDensity += value;
				if (Double.isNaN(value)) {
					System.out.println("dddNaN1!");
				}
			}
		}
		return logDensity;
	}
	
	public String saveCluster() {
		String clusterParameter = "";
		
		// pi
		clusterParameter = clusterParameter + pi;
		
		// mu
		for (int f=0; f<FEATURE_NUM; f++) {
			clusterParameter = clusterParameter + "\t" + distributions[f].saveCluster();
		}

		return clusterParameter;
	}
	
	public void loadCluster(String s) {
		String[] ss = s.split("\t");
		
		pi = Double.valueOf(ss[0]);
		
		for (int f=0; f<FEATURE_NUM; f++) {
			distributions[f].loadCluster(ss[f+1]);
		}
	}
}
