package independentMixtureModel;

abstract class Distribution{
	static int FEATURE_NUM;
	static int CLUSTER_NUM;
	static int DATA_SIZE;
	
	// local parameter for each distribution (for incomplete data)
	double Nk_local;
	
	public abstract void initWorkArea();
	
	public abstract void updateWorkArea(double w, String x);
	
	public abstract void initHyperParameter();
	
	public abstract void updateHyperParameter();
	
	public abstract void updateDistribution();
	
	public abstract double getLogDensity(String x);
	
	public abstract String saveCluster();
	
	public abstract void loadCluster(String s);
}
