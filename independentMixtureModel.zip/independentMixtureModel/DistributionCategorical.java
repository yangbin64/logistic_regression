package independentMixtureModel;

import java.util.*;
import org.apache.commons.math3.distribution.*;

public class DistributionCategorical extends Distribution {

	double alpha = 50;
	
	// Parameters
	int C;
	HashMap<String, Double> probabilities;
	
	// Work area
	HashMap<String, Double> n;
	//double N = 0;
	
	//EnumeratedDistribution<String> categorical;
	
	public DistributionCategorical(String parameter) {
		String[] parameters = parameter.split(";");
		
		String[] keys = parameters[0].split(",");
		C = keys.length;
		
		probabilities = new HashMap<String, Double>();
		for (int c=0; c<C; c++) {
			String key = keys[c];
			probabilities.put(key, 1.0/C);
		}
		
		alpha = Double.valueOf(parameters[1]);
	}
	
	public void initWorkArea() {
		//Nk_local = 0;
		
		n = new HashMap<String, Double>();
		
		for (Iterator<Map.Entry<String, Double>> it=probabilities.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Double> entry = it.next();
			String key = entry.getKey();
			
			n.put(key, alpha);
		}

		//N = 0;
	}
	
	public void updateWorkArea(double w, String x) {
		//Nk_local += w;
		
		double value = n.get(x);
		n.put(x, value + w);
		//N += w;
	}
	
	public void initHyperParameter() {
		GammaDistribution gamma = new GammaDistribution(alpha, 1.0);
		
		double[] g = new double[C];
		double sum_g = 0;
		
		for (int c=0; c<C; c++) {
			g[c] = gamma.sample();
			sum_g += g[c];
		}
		
		int c=0;
		for (Iterator<Map.Entry<String, Double>> it=probabilities.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Double> entry = it.next();
			String key = entry.getKey();
			//double value = entry.getValue();
			probabilities.put(key, g[c]/sum_g);
			c++;
		}
	}
	
	public void updateHyperParameter() {
		double sum_p = 0;
		
		for (Iterator<Map.Entry<String, Double>> it=probabilities.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Double> entry = it.next();
			String key = entry.getKey();
			
			double value = n.get(key);
			probabilities.put(key, value + alpha);
			sum_p += (value + alpha);
		}
		
		for (Iterator<Map.Entry<String, Double>> it=probabilities.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Double> entry = it.next();
			String key = entry.getKey();
			
			double value = probabilities.get(key);
			probabilities.put(key, value/sum_p);
		}
	}
	
	public void updateDistribution() {
	}
	
	public double getLogDensity(String x) {
		return probabilities.get(x);
	}
	
	public String saveCluster() {
		String clusterParameter = "";
		
		for (Iterator<Map.Entry<String, Double>> it=probabilities.entrySet().iterator(); it.hasNext(); ) {
			Map.Entry<String, Double> entry = it.next();
			String key = entry.getKey();
			double value = entry.getValue();
			
			clusterParameter += key + ":" + value + ";";
		}
		clusterParameter = clusterParameter.substring(0, clusterParameter.length()-1);

		return clusterParameter;
	}
	
	public void loadCluster(String s) {
		String[] ss = s.split(";");
		
		probabilities = new HashMap<String, Double>();
		
		// probabilities
		for (int c=0; c<C; c++) {
			String[] sss = ss[c].split(":");
			String key = sss[0];
			double probability = Double.valueOf(sss[1]);
			probabilities.put(key, probability);
		}
		
		// distribution
		updateDistribution();
	}
}
