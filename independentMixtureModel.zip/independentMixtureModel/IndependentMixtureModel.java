package independentMixtureModel;

import java.io.*;

public class IndependentMixtureModel {

	Cluster[] clusters;
	
	Parameter parameter;
	
	public IndependentMixtureModel(
			String filenameParameter) {
		parameter = new Parameter();
		parameter.importJson(filenameParameter);
		
		Cluster.FEATURE_NUM = parameter.parameterlist.FEATURE_NUM;
		Cluster.CLUSTER_NUM = parameter.parameterlist.CLUSTER_NUM;
		
		clusters = new Cluster[parameter.parameterlist.CLUSTER_NUM];
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c] = new Cluster(parameter.parameterlist.TYPE_LIST);
		}
	}
	
	public void countSize() {
		int recordcount = 0;
		
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			
			while ((buf.readLine())!=null) {
				recordcount++;
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		
		parameter.parameterlist.DATA_SIZE = recordcount;
		Cluster.DATA_SIZE = recordcount;
		Distribution.DATA_SIZE = recordcount;
		
		System.out.println("User # is " + recordcount);
	}
	
	public void EStep() {
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c].initWorkArea();
		}
		
		int count = 0;
		int count_sum0 = 0;
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			String s=buf.readLine();
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t");
				
				String[] xx = new String[parameter.parameterlist.FEATURE_NUM];
				for (int f=0; f<parameter.parameterlist.FEATURE_NUM; f++) {
					xx[f] = ss[f+parameter.parameterlist.HAS_ID];
				}
				
				EStep(xx);
				
				count++;
				if (count%5000000==0)
					System.out.print("," + count);
			}
			
			if (count_sum0>0) {
				System.out.println(" [# of sum=0] is " + count_sum0);
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void EStep(String[] xx) {
		// compute w
		double[] w = computeW(xx);
		
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			// update for M-step (Nk, sum_mu)
			clusters[c].updateWorkArea(w[c], xx);
		}
	}
	
	public double[] computeW(String[] xx) {
		// compute w
		double[] logDensity = new double[parameter.parameterlist.CLUSTER_NUM];
		double[] density = new double[parameter.parameterlist.CLUSTER_NUM];
		double[] w = new double[parameter.parameterlist.CLUSTER_NUM];
		
		double maxLogDensity = -1.0E308;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			logDensity[c] = clusters[c].getLogDensity(xx) + Math.log(clusters[c].pi);
			if (logDensity[c]>maxLogDensity) {
				maxLogDensity = logDensity[c];
			}
		}
		
		double sumDensity = 0;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			logDensity[c] -= maxLogDensity;
			density[c] = Math.exp(logDensity[c]);
			sumDensity += density[c];
		}
		
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			w[c] = density[c]/sumDensity;
			if (Double.isNaN(w[c])) {
				System.out.println("NaN1!");
			}
		}
		
		return w;
	}
	
	// update parameters
	public void MStep() {
		// compute Pi
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c].updatePi();
		}
		
		// update hyper-parameter
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c].updateHyperParameter();
		}
		
		// update distribution
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			clusters[c].updateDistribution();
		}
	}
	
	public void evaluatePi() {
		double sum_logPi = 0;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			sum_logPi += Math.log(clusters[c].pi);
			int v = (int)(clusters[c].pi*1000);
			System.out.print("" + v + "‰\t");
		}
		double ave = sum_logPi/parameter.parameterlist.CLUSTER_NUM;
		System.out.println("Ave log pi = " + ave);
	}
	
	public void saveClusters(String filename) {
		try {
			FileWriter fw = new FileWriter(filename);
			
			for (int c=0; c<clusters.length; c++) {
				String clusterParameter = clusters[c].saveCluster();
				
				fw.write(clusterParameter + "\n");
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void loadClusters(String filename) {
		try {
			FileReader fr = new FileReader(filename);
			BufferedReader buf = new BufferedReader(fr);
			String s;
			
			int c=0;
			while ((s=buf.readLine())!=null) {
				clusters[c].loadCluster(s);
				c++;
			}
			
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void train(int r_begin, int r_end) {
		// Continue training
		if (r_begin>0) {
			int last = r_begin - 1;
			loadClusters(parameter.parameterlist.pathname_dump + "Clusters_" + last + ".log");
		}
		
		try {
			FileWriter fw = new FileWriter(parameter.parameterlist.pathname_dump + "loglikelihood.dmp");
			
			for (int r=r_begin; r<=r_end; r++) {
				System.out.println("Round " + r + "...");
				EStep();
				MStep();
				evaluatePi();
				
				if (r%20==0) {
					saveClusters(parameter.parameterlist.pathname_dump + "Clusters_" + r + ".log");
				}
				
				double ll = computeLogLikelihood();
				fw.write("" + ll + "\n");
			}
			
			fw.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public void assignLabels() {
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_training);
			BufferedReader buf = new BufferedReader(fr);
			String s=buf.readLine();
			
			FileWriter fw = new FileWriter(parameter.parameterlist.filename_result);
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t");
				
				String[] xx = new String[parameter.parameterlist.FEATURE_NUM];
				boolean bNG = true;
				for (int f=0; f<parameter.parameterlist.FEATURE_NUM; f++) {
					xx[f] = ss[f+parameter.parameterlist.HAS_ID];
					if (!xx[f].equalsIgnoreCase("NG")&&!xx[f].equalsIgnoreCase("")) {
						bNG = false;
					}
				}
				
				if (bNG) {
					fw.write("" + "NG" + "\t" + s + "\n");
				} else {
					int c_max = assignLabels(xx);
					fw.write("" + c_max + "\t" + s + "\n");
				}
			}
			
			fw.close();
			fr.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public double[] computeLikelihoodList(String[] xx) {
		// compute w
		double[] logLikelihoodList = new double[parameter.parameterlist.CLUSTER_NUM];
		
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			logLikelihoodList[c] = clusters[c].getLogDensity(xx);
		}
		
		return logLikelihoodList;
	}
	
	public int assignLabels(String[] xx) {
		// compute w
		//double[] w = computeW(xx);
		double[] w = computeLikelihoodList(xx);
		
		int c_max = 0;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			if (w[c] > w[c_max]) {
				c_max = c;
			}
		}
		
		return c_max;
	}
	
	public double computeLogLikelihood() {
		double sum_ll = 0;
		int count = 0;
		
		try {
			FileReader fr = new FileReader(parameter.parameterlist.filename_testing);
			BufferedReader buf = new BufferedReader(fr);
			String s=buf.readLine();
			
			while ((s=buf.readLine())!=null) {
				String[] ss=s.split("\t");
				
				String[] xx = new String[parameter.parameterlist.FEATURE_NUM];
				for (int f=0; f<parameter.parameterlist.FEATURE_NUM; f++) {
					xx[f] = ss[f+parameter.parameterlist.HAS_ID];
				}
				
				double logLikelihood = computeLogLikelihood(xx);
				sum_ll += logLikelihood;
				count++;
				
				if (count%2000==0) {
					System.out.print("*");
				}
			}
			
			fr.close();
		} catch(Exception e) {
			System.out.println(e);
		}
		
		double ll = sum_ll/count;
		
		System.out.println("Log Likelihood: " + ll);
		
		return ll;
	}
	
	public double computeLogLikelihood(String[] xx) {
		double[] logDensity = new double[parameter.parameterlist.CLUSTER_NUM];
		double[] density = new double[parameter.parameterlist.CLUSTER_NUM];
		
		double maxLogDensity = -1.0E308;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			double logDen = clusters[c].getLogDensity(xx);
			logDensity[c] = logDen + Math.log(clusters[c].pi);
			
			if (logDensity[c]>maxLogDensity) {
				maxLogDensity = logDensity[c];
			}
		}
		
		double sumDensity = 0;
		for (int c=0; c<parameter.parameterlist.CLUSTER_NUM; c++) {
			logDensity[c] -= maxLogDensity;
			density[c] = Math.exp(logDensity[c]);
			sumDensity += density[c];
		}
		
		double logSumDensity = Math.log(sumDensity) + maxLogDensity;
		
		return logSumDensity;
	}
	
	public void run(String flg) {
		countSize();
		
		if (flg.equalsIgnoreCase("testing")) {
			System.out.println("Loading model...");
			loadClusters(parameter.parameterlist.filename_model);
			
		} else if (flg.equalsIgnoreCase("training")) {
			System.out.println("Training from round " + parameter.parameterlist.start + "...");
			train(parameter.parameterlist.start, parameter.parameterlist.end);
			
			System.out.println("Assigning labels...");
			assignLabels();
			
		} else if (flg.equalsIgnoreCase("assigning")) {
			System.out.println("Loading model...");
			loadClusters(parameter.parameterlist.filename_model);
			
			System.out.println("Assigning labels...");
			assignLabels();
		}
		
		System.out.println("Computing log likelihood...");
		computeLogLikelihood();
	}
	
	public static void main(String[] args) {
		String flg = args[0];
		String filenameParameter = args[1];
		
		IndependentMixtureModel imm = new IndependentMixtureModel(filenameParameter);
		
		imm.run(flg);
	}

}
